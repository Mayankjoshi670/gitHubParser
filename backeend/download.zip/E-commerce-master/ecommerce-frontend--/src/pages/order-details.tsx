const OrderDetails = () => {
  return <div>OrderDetails</div>;
};

export default OrderDetails;